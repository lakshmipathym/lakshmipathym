const listBoxItemsContainer = document.getElementById('listBoxItemsContainer');

const listBoxButton = document.querySelector('.list-box-button');

var i = parseInt(0);

var inputValue = document.getElementById('inputValue');

listBoxButton.addEventListener('click', () => {
    const listItems = document.createElement('div');
    listItems.className= 'list-box-items';
    const listItmesSpan = document.createElement('span');
    listItmesSpan.className="material-symbols-outlined icons-size-20";
    listItmesSpan.innerText="more_vert";

    const lableBoxLabel = document.createElement('label');
    lableBoxLabel.className = 'list-box-label';

    const inputCheckBox = document.createElement('input');
    inputCheckBox.setAttribute('type', 'checkbox');
    inputCheckBox.setAttribute('id', `checkbox-${i}`);
    inputCheckBox.setAttribute('name', 'toDoListIndex');
    inputCheckBox.setAttribute('class','list-box-input');
    inputCheckBox.setAttribute('value', 0);

    const labelTextValue = document.createElement('span');
    labelTextValue.className = 'list-box-label-text';
    labelTextValue.innerText= inputValue.value;

    lableBoxLabel.append(inputCheckBox,labelTextValue);

    const listBoxInfo = document.createElement('span');
    listBoxInfo.className = 'list-box-create-info';
    

    const listItemsSpan1 = document.createElement('span');
    listItemsSpan1.className = 'material-symbols-outlined icons-size-12';
    listItemsSpan1.innerText= 'schedule';

    const listScheduleTime = document.createElement('span');
    listScheduleTime.innerText= '2 mins';

    listBoxInfo.append(listItemsSpan1,listScheduleTime)

    const listItemsEdit = document.createElement('span');
    listItemsEdit.className = 'list-box-items-edit';


    const listEditButtonItems = document.createElement('button');
    listEditButtonItems.setAttribute('type', 'button');
    listEditButtonItems.setAttribute('onclick', "editBtn(event)");

    const listItemsSpan2 = document.createElement('span');
    listItemsSpan2.className = 'material-symbols-outlined';
    listItemsSpan2.innerText ='edit_note';

    listEditButtonItems.append(listItemsSpan2);

    listItemsEdit.append(listEditButtonItems);

    listItems.append(listItmesSpan,lableBoxLabel,listBoxInfo,listItemsEdit);

    listBoxItemsContainer.append(listItems);

    i = i+1;
});



function editBtn(event){
    const removeEl = document.querySelector('.list-box-label-text');
    removeEl.remove();
    const changeInput = document.createElement('input');
    changeInput.className='change-input';
    changeInput.setAttribute('type', 'text');
    changeInput.setAttribute('value', inputValue.value);
    const newLabel = document.querySelector('.list-box-label');
    newLabel.append(changeInput);
    console.log(newLabel);

}
