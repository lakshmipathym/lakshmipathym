// const main = document.getElementById("main");
// function domElement1(message) {
//    const div = document.createElement('div');
//    div.className = 'alert';
//    const textNode = document.createTextNode(message);
//    div.append(textNode);
//    main.prepend(div);
//    console.log(main);
// };
// domElement1("it's successful");
// for(i = 1; i <= 1000; i++){
//     const foodItems = document.getElementById('food-list-items-container');
//     const li = document.createElement('li');
//     li.textContent = `counting details ${i}`;
//     li.className = 'food-list-items';
//     foodItems.append(li);
// }
// const foodItems1 = document.getElementById('food-list-items-container');
// const forment = document.createDocumentFragment();
// for(i = 1; i <= 1000; i++){
//     const li = document.createElement('li');
//     li.textContent = `counting details ${i}`;
//     li.className = 'food-list-items';
//     forment.append(li);
// }
// foodItems1.append(forment);
// const foodNonVeg = ["briyani", "chicken briyani", "mutton briyani", "brown briyani"];
// foodNonVeg.forEach((food) => {
//     const li = document.createElement('li');
//     li.textContent = food;
//     li.className = 'food-list-items';
//     forment.append(li);
// });
// foodItems1.append(forment);
// const li = document.createElement('li');
// li.textContent = 'hi vanakkam';
// li.className = 'food-list-items';
// foodItems1.after(li);

// foodItems1.insertAdjacentHTML('afterbegin' ,'<li>vankkam</li>');

// foodItems1.insertAdjacentHTML('afterend', '<li>hi hello</li>');

// foodItems1.insertAdjacentHTML('beforebegin', '<li>hello world</li>');

// const foodListMenu = document.querySelector(".food-list-items-container :first-child");
// const buttonList = document.getElementById('button-list');
// buttonList.addEventListener('click', () => {
// const li = document.createElement('li');
// li.textContent = 'lakshmipathy';
// li.className = 'food-list-items';
// const li1 = document.createElement('li');
// li1.textContent = 'lakshmipathy';
// li1.className = 'food-list-items';
// foodListMenu.replaceWith(li, li1);
// });
// const foodItemsContainer = document.getElementById('food-list-items-main');
// const dupplicate = document.getElementById('dupplicate');
// const buttonList = document.getElementById('button-list');
// buttonList.addEventListener('click', () => {
//     dupplicate.innerHTML = '';
//     const clouneNode = foodItemsContainer.cloneNode(true);
//     dupplicate.append(clouneNode);
// });


// const foodItemsEl = [
//     'muttan priyani',
//     'chicken priyani',
//     'egg priyani'
// ];

// for(let i = 0; i < foodItemsEl.length; i++) {
//     console.log(foodItemsEl[i]);
// }

// foodItemsEl.forEach((food) => {
//     console.log(food);
// });
// const foodItemsEl = document.querySelectorAll(".food-list-items-container li");

// const foodItemsValue = [];

// for(const items of foodItemsEl) {
//     foodItemsValue.push(items.innerText);
// }

// console.log(foodItemsValue);

// foodItemsEl.forEach((food)=> {
//     console.log(food);
// });

// const newFoodItems = [...foodItemsEl].forEach((food)=> {
//     console.log(food);
// });

// console.log(newFoodItems);


const foodListContainerEl = document.querySelector('#food-list-items-container');

console.log(foodListContainerEl.children, foodListContainerEl.childElementCount, foodListContainerEl.firstElementChild);

console.log(foodListContainerEl.children.length);

const foodListItems = document.querySelectorAll('li');

console.log(foodListItems);
