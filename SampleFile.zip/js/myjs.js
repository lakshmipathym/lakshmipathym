let foodItems = document.getElementById('food-items');
let inputButton = document.getElementById('input-button');

let foodListItemsContainer = document.getElementById('food-list-items-container');

inputButton.addEventListener('click', () => {
   const li = document.createElement('li');
   const text = document.createTextNode(foodItems.value);
   li.className = 'food-list-items';
  
   foodListItemsContainer.append(li);
   const divEl = document.createElement('div');
   const divRemove = document.createElement('div');
   divEl.append(text);
   li.append(divEl, divRemove);
   divRemove.innerHTML = `<li class='food-icons'>X</li>`;
   divRemove.setAttribute('onclick', "removeEl(event)");
   console.log(li);
});

function removeEl(event) {
  removeElment = event.target.parentNode.parentNode;
  removeElment.remove();
}

